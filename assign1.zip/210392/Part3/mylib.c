#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>

unsigned long head = 0;
size_t MB4 = 4 * 1024 * 1024;
int debug = 0;
void *memalloc(unsigned long size)
{
	// printf("memalloc() called\n");
	if (size == 0)
		return NULL;
	// creating size in multiples of 8 and 8 more bytes are reqd for storing the size
	int reqd = (size % 8 != 0) * 8 + 8 + (size / 8) * 8;
	if (reqd < 24)
		reqd = 24;
	if (head == 0)
	{
		int mem_size = ((reqd % MB4 != 0) + reqd / MB4) * MB4;
		void *ptr = mmap(NULL, mem_size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
		if (ptr == MAP_FAILED)
		{
			return NULL;
		}
		unsigned long *data = (unsigned long *)ptr;
		data[0] = mem_size;
		data[1] = 0;
		data[2] = 0;
		head = (unsigned long)data;
		if (debug)
			printf("Memory tape1 %p %p\n", head, head + (void *)((unsigned long *)head)[0]);
	}
	unsigned long *ptr = ((unsigned long *)head);
	if (debug)
		printf("Size %ld %p %p\n", ptr[0], (unsigned long *)ptr[1], (unsigned long *)ptr[2]);

	while (ptr[1] != 0 && ptr[0] < reqd)
	{
		ptr = ((unsigned long *)ptr[1]);
	}
	if (ptr[0] < reqd)
	{
		int mem_size = ((reqd % MB4 != 0) + (reqd / MB4)) * MB4;
		void *ptr2 = mmap(NULL, mem_size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
		// printf("%ld %p %p\n",(long int)(ptr2 - Memory_end) / MB4,Memory_end,ptr2);
		if (ptr2 == MAP_FAILED)
		{
			// perror("mmap");
			return NULL;
		}
		unsigned long *data = (unsigned long *)ptr2;

		data[0] = mem_size;
		data[1] = head;
		data[2] = 0;
		if (head != 0)
		{
			((unsigned long *)head)[2] = (unsigned long)data;
		}
		head = (unsigned long)data;
		ptr = data;

		if (debug)
		{
			printf("Memory tape2 %p %p\n", head, head + ((unsigned long *)head)[0]);
		}
	}
	if (ptr[0] - reqd < 24)
	{
		if (debug)
		{
			printf("IF\n");
		}
		unsigned long *ptr_prev = (unsigned long *)ptr[2], *ptr_next = (unsigned long *)ptr[1];
		// ptr[1] = 0;
		// ptr[2] = 0;
		if (ptr_prev != 0)
		{
			ptr_prev[1] = (unsigned long)ptr_next;
		}
		if (ptr_next != 0)
		{
			ptr_next[2] = (unsigned long)ptr_prev;
		}
		if (ptr_prev == 0)
		{
			head = (unsigned long)ptr_next;
		}
	}
	else
	{
		if (debug)
		{
			printf("In else\n");
		}

		unsigned long *ptr_prev = (unsigned long *)ptr[2], *ptr_next = (unsigned long *)ptr[1];
		// ptr[1] = 0;
		// ptr[2] = 0;
		if (ptr_prev != 0)
		{
			ptr_prev[1] = (unsigned long)ptr_next;
		}
		if (ptr_next != 0)
		{
			ptr_next[2] = (unsigned long)ptr_prev;
		}
		if (ptr_prev == 0)
		{
			head = (unsigned long)ptr_next;
		}
		ptr_next = (unsigned long *)head;
		ptr[reqd / 8 + 2] = 0;
		ptr[reqd / 8 + 1] = head;
		ptr[reqd / 8] = ptr[0] - reqd;
		ptr[0] = reqd;
		if(ptr_next!=0)
		{
			ptr_next[2]=&ptr[reqd / 8];
		}
		head=&ptr[reqd / 8];
		if (debug)
			printf("start %p End %p of free mem chunk\n", &ptr[reqd / 8], ((unsigned long *)ptr)[reqd / 8] + (unsigned long)(&ptr[reqd / 8]));
	}
	if (debug)
		printf("Memory_Allocated=%p %ld %p\n\n", (void *)ptr, ((unsigned long *)ptr)[0], (void *)ptr + ((unsigned long *)ptr)[0]);
	return (void *)ptr + 8; // Return the stored memory block address
}

int memfree(void *ptr)
{
	//	printf("memfree() called\n");

	if (ptr == 0)
		return -1;
	if (head == 0)
	{
		head = ptr - 8;
		((unsigned long *)head)[1] = 0;
		((unsigned long *)head)[2] = 0;
		return 0;
	}
	ptr -= 8;
	ptr = (unsigned long *)ptr;
	if (debug)
		printf("memfree() called for %p\n", ptr);
	unsigned long start = (unsigned long)ptr;
	unsigned long end = (unsigned long)(start + ((unsigned long *)ptr)[0]);
	if (debug)
		printf("%p %p\n", ptr, (unsigned long *)end);
	int f1 = 0, f2 = 0;
	unsigned long *st = (unsigned long *)head;
	while (st != 0)
	{
		if ((unsigned long)st == end)
			f1++;
		if (st[0] + (unsigned long)st == start)
			f2++;
		st = ((unsigned long *)st)[1];
	}
	if (debug)
		printf("The mem to be deallocated ends in %d starts at %d\n", f1, f2);
	if (f1 > 1 || f2 > 1)
	{
		printf("Error\n");
	}
	st = (unsigned long *)head;
	if (f1 && f2)
	{
		unsigned long size = ((unsigned long *)ptr)[0], *p1;

		while (st != 0)
		{
			if ((unsigned long)st == end)
			{
				size += st[0];
				if (debug)
				{
					printf("2%p\n", st);
				}
				unsigned long *ptr_prev = (unsigned long *)st[2], *ptr_next = (unsigned long *)st[1];
				if (ptr_prev != 0)
				{
					ptr_prev[1] = (unsigned long)ptr_next;
				}
				if (ptr_next != 0)
				{
					ptr_next[2] = (unsigned long)ptr_prev;
				}
				if (ptr_prev == 0)
				{
					head = (unsigned long)ptr_next;
				}
				//	print_free();
			}
			else if (st[0] + (unsigned long)st == start)
			{
				p1 = st;
				size += st[0];
				if (debug)
				{
					printf("1 %p\n", st);
				}
				unsigned long *ptr_prev = (unsigned long *)st[2], *ptr_next = (unsigned long *)st[1];
				if (debug)
					printf("1 %p %p\n", st, ptr_prev, ptr_next);

				if (ptr_prev != 0)
				{
					ptr_prev[1] = (unsigned long)ptr_next;
				}
				if (ptr_next != 0)
				{
					ptr_next[2] = (unsigned long)ptr_prev;
				}
				if (ptr_prev == 0)
				{
					head = (unsigned long)ptr_next;
				}
				// print_free();
			}

			st = ((unsigned long *)st)[1];
		}
		p1[0] = size;
		p1[1] = (unsigned long)head;
		p1[2] = 0;
		if (head != 0)
		{
			((unsigned long *)head)[2] = (unsigned long)p1;
		}
		head = p1;
	}
	else if (f1)
	{
		// increase the size
		while (st != 0)
		{
			if ((unsigned long)st == end)
			{

				break;
			}

			st = ((unsigned long *)st)[1];
		}
		unsigned long *ptr2 = ptr;
		ptr2[0] += ((unsigned long *)st)[0];
		unsigned long *ptr_prev = (unsigned long *)st[2], *ptr_next = (unsigned long *)st[1];
		if (debug)
			printf("f1 %p %p %p\n\n", ptr_prev, st, ptr_next);

		if (ptr_prev != 0)
		{
			ptr_prev[1] = (unsigned long)ptr_next;
		}
		if (ptr_next != 0)
		{
			ptr_next[2] = (unsigned long)ptr_prev;
		}
		if (ptr_prev == 0)
		{
			head = (unsigned long)ptr_next;
		}
		// printf("hi2 %p\n", st);

		unsigned long *next = (unsigned long *)head;
		// printf("hi3 %p\n", st);

		head = (unsigned long)ptr2;
		// printf("hi4 %p\n", st);

		((unsigned long *)ptr2)[2] = 0;
		((unsigned long *)ptr2)[1] = (unsigned long)next;
		if (next != 0)
			next[2] = head;
		if (debug)
			printf("to be dellocated %p common:%p head:%p\n\n", ptr, st, head);

		// printf("hi5 %p\n", st);
	}
	else if (f2)
	{
		// to be completed
		unsigned long size = ((unsigned long *)ptr)[0], *p1;

		while (st != 0)
		{
			if (st[0] + (unsigned long)st == start)
			{
				p1 = st;
				size += st[0];
				unsigned long *ptr_prev = (unsigned long *)st[2], *ptr_next = (unsigned long *)st[1];
				if (ptr_prev != 0)
				{
					ptr_prev[1] = (unsigned long)ptr_next;
				}
				if (ptr_next != 0)
				{
					ptr_next[2] = (unsigned long)ptr_prev;
				}
				if (ptr_prev == 0)
				{
					head = (unsigned long)ptr_next;
				}
				break;
			}

			st = ((unsigned long *)st)[1];
		}
		p1[0] = size;
		p1[1] = (unsigned long)head;
		p1[2] = 0;
		if (head != 0)
		{
			((unsigned long *)head)[2] = (unsigned long)p1;
		}
		head = p1;
	}
	else
	{
		unsigned long *next = (unsigned long *)head;
		head = (unsigned long)ptr;
		((unsigned long *)ptr)[2] = 0;
		((unsigned long *)ptr)[1] = (unsigned long)next;
		if (next != 0)
			next[2] = head;
	}
	if (debug)
		printf("Head %p\n\n", head);
	return 0;
}


