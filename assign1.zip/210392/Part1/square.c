#include <stdio.h>
#include <string.h>
#include <unistd.h>
int isnumeric(char *str)
{
	int i = 0;
	while (str[i] != '\0')
	{
		if (str[i] > '9' || str[i] < '0')
			return 1;
		i++;
	}
	return 0;
}
int main(int argc, char *argv[])
{
	if (argc < 2 || isnumeric(argv[argc - 1]))
	{
		printf("Unable to execute\n");
		return 0;
	}
	char *help;
	unsigned long val = strtoul(argv[argc - 1], &help, 10);
	// printf("%s %s %lu\n", __FILE__, argv[0], val);
	sprintf(argv[argc - 1], "%lu", val * val);
	if (argc > 2)
	{
		if (execv(argv[1], argv + 1) == -1)
		{
			printf("Unable to execute\n");
			return 0;
		}
	}
	else
		printf("%s\n", argv[argc - 1]);

	return 0;
}
