#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <dirent.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
// variable used for debugging
int debug = 2; // stderror by default
int debugstat = 0;
// make debug stat=1 if you want debugging statements
unsigned long long recursive(char *path)
{
	if(path==0)return 0;
    char buf[4096];
    pid_t pid;
    int len;
    unsigned long long ans = 0;
    struct dirent *de;

    struct stat sbuf;
    if (stat(path, &sbuf) == 0)
    {
        if (debugstat)
        {
            len = sprintf(buf, "\nRecur::inode = %lu size = %ld\n", (unsigned long)sbuf.st_ino, (long)sbuf.st_size);
            write(debug, buf, len);
        }
        ans += (long)sbuf.st_size;
    }
    else
    {
	//	printf("Hello\n");
	//	printf("%s\n",path);
       // perror("Error getting file information1\n");
		return 0;
    }
    DIR *dr = opendir(path);
    if (dr == NULL)
    {
        if (debugstat)
        {
            strcpy(buf, "Can't open the directory\n");
            write(debug, buf, len);
        }
        return 0;
    }
    while ((de = readdir(dr)) != NULL)
    {
        if (de->d_type == DT_REG)
        {
            char path2[4096];
            strcpy(path2, path);
            strcat(path2, "/");
            strcat(path2, de->d_name);
            if (debugstat)
            {
                len = sprintf(buf, "Recur::File: %s\n", path2);
                write(debug, buf, len);
            }
            struct stat sbuf;
            if (stat(path2, &sbuf) == 0)
            {
                if (debugstat)
                {
                    len = sprintf(buf, "Recur::inode = %lu size = %ld\n", (unsigned long)sbuf.st_ino, (long)sbuf.st_size);
                    write(debug, buf, len);
                }
                ans += (long)sbuf.st_size;
            }
            else
            {
                perror("Error getting file information\n");
            }
        }
        else if (de->d_type == DT_LNK)
        {
            char path2[4096];
            strcpy(path2, path);
            strcat(path2, "/");
            strcat(path2, de->d_name);
            if (debugstat)
            {
                len = sprintf(buf, "Recur::File: %s\n", path2);
                write(debug, buf, len);
            }
            ans += recursive(path2);
        }

        else if (de->d_type == DT_DIR)
        {
            if ((char)de->d_name[0] == '.')
                continue;
            char path2[4096];
            strcpy(path2, path);
            strcat(path2, "/");
            strcat(path2, de->d_name);
            ans += recursive(path2);
        }
        else
        {
            if (debugstat)
            {
                len = sprintf(buf, "Other: %s\n", de->d_name);
                write(debug, buf, len);
            }
        }
    }
    return ans;
}
int main(int argc, char *argv[])
{

    if (argc < 2)
    {
        printf("Unable to execute\n");
        return 0;
    }
    if (debugstat)
    {
        debug = open("Help.txt", O_CREAT | O_RDWR | O_APPEND);
    }
    char buf[4096];
    pid_t pid;
    int len;
    unsigned long long ans = 0;
    if (debugstat)
    {
        len = sprintf(buf, "fd 0f Help%d\n", debug);
        write(debug, buf, len);
    }
    struct dirent *de;
    char path[4096];

    strcat(path, argv[1]);

    struct stat sbuf;
    if (stat(path, &sbuf) == 0)
    {
        if (debugstat)
        {
            len = sprintf(buf, "inode = %lu size = %ld\n", (unsigned long)sbuf.st_ino, (long)sbuf.st_size);
            write(debug, buf, len);
        }
        ans += (long)sbuf.st_size;
    }
    else
    {
        perror("Error getting file information\n");
    }
    DIR *dr = opendir(path);
    if (dr == NULL)
    {
        printf("Unable to execute\n");
        if (debugstat)
        {
            strcpy(buf, "Can't open the directory\n");
            write(debug, buf, len);
        }
        return 0;
    }
    while ((de = readdir(dr)) != NULL)
    {
        if (de->d_type == DT_REG)
        {
            char path2[4096];
            strcpy(path2, path);
            strcat(path2, "/");
            strcat(path2, de->d_name);
            if (debugstat)
            {
                len = sprintf(buf, "File: %s\n", path2);
                write(debug, buf, len);
            }
            struct stat sbuf;
            if (stat(path2, &sbuf) == 0)
            {
                if (debugstat)
                {
                    len = sprintf(buf, "inode = %lu size = %ld\n", (unsigned long)sbuf.st_ino, (long)sbuf.st_size);
                    write(debug, buf, len);
                }
                ans += (long)sbuf.st_size;
            }
            else
            {
                perror("Error getting file information\n");
            }
        }
        else if (de->d_type == DT_LNK)
        {
            if (debugstat)
            {
                len = sprintf(buf, "HII i AM SYM_link\n");
                write(debug, buf, len);
            }

            char path2[4096];
            strcpy(path2, path);
            strcat(path2, "/");
            strcat(path2, de->d_name);
            if (debugstat)
            {
                len = sprintf(buf, "File: %s\n", path2);
                write(debug, buf, len);
            }
            ans += recursive(path2);
        }
        else if (de->d_type == DT_DIR)
        {

            // continue;
            if ((char)de->d_name[0] == '.')
                continue;

            char path2[4096];
            strcpy(path2, argv[1]);
            strcat(path2, "/");
            strcat(path2, de->d_name);
            len = sprintf(buf, "\nDirectory: %s\n", path2);
            if (argc > 2)
            {
                ans += recursive(path2);
            }
            else
            {
                int fd[2];
                if (pipe(fd) < 0)
                {
                    perror("pipe");
                    exit(-1);
                }
                pid = fork();
                if (debugstat)
                {
                    len = sprintf(buf, "Child PID %d parent %d %s\n", pid, getpid(), path2);
                    write(debug, buf, len);
                }
                if (pid < 0)
                {
                    perror("fork");
                    exit(-1);
                }
                if (pid == 0)
                {

                    // close(fd[0]); // Close the read end in the parent
                    close(1);   // Close the standard output
                    dup(fd[1]); // Now 1 is fd[1]!
                    if (debugstat)
                    {
                        len = sprintf(buf, "Calling exec for %s\n", path2);
                        write(debug, buf, len);
                    }
                    printf("%llu\n",recursive(path2));
                     exit(0);
                }
                else
                {
                    unsigned long long v = 0;
                    int status;

                    wait(0);
                    close(0);
                    dup(fd[0]);
                    scanf("%lld", &v);
                    if (debugstat)
                    {
                        len = sprintf(buf, "exec returned for %s %lld\n", path2, v);
                        write(debug, buf, len);
                    }
                    ans += v;
                }
            }
        }
        else
        {
            if (debugstat)
            {
                len = sprintf(buf, "Other: %s\n", de->d_name);
                write(debug, buf, len);
            }
        }
    }
    printf("%lld\n", ans);
    if (argc > 0)
    {
        if (debugstat)
        {
            len = sprintf(buf, "Last %s %lld\n", argv[1], ans);
            write(debug, buf, len);
        }
    }
    closedir(dr);
    if (debugstat)
        close(debug);
    return 0;
}
