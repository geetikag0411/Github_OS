#include <types.h>
#include <mmap.h>
#include <fork.h>
#include <v2p.h>
#include <page.h>
static int KB4 = 4 * 1024;
// tested till tc7
/*
 * You may define macros and other helper functions here
 * You must not declare and use any static/global variables
 * */

/**
 * mprotect System call Implementation.
 */
static int debug = 0;
static int debug2 = 0;

int merge(struct vm_area *left, struct vm_area *right)
{
    if (left == 0 || right == 0)
        return 1;
    if (left->vm_end == right->vm_start && left->access_flags == right->access_flags)
    {
        left->vm_end = right->vm_end;
        struct vm_area *next = right->vm_next;
        os_free(left->vm_next, sizeof(struct vm_area));
        left->vm_next = next;
        stats->num_vm_area--;
        return 0;
    }
    return 1;
}
void complete_merge(struct vm_area *vma)
{
    while (vma->vm_next != 0)
    {
        if (merge(vma, vma->vm_next))
            vma = vma->vm_next;
    }
}
struct vm_area *insert(struct vm_area *next, unsigned long st, unsigned long ed, u32 f)
{
    struct vm_area *v = os_alloc(sizeof(struct vm_area));
    v->vm_start = st;
    v->vm_end = ed;
    v->access_flags = f;
    v->vm_next = next;
    return v;
}
void flush_tlb()
{
    asm volatile(
        "mov %cr3, %rax;"
        "mov %rax, %cr3;");
    return;
}
int change_permission_pg(struct exec_context *current, u64 st_addr, int lenght, int prot)
{
    flush_tlb();
    if (debug2)
        printk("change_permission_pg: st_addr: %x, length: %x, prot: %x\n", st_addr, lenght, prot);

    for (int i = 0; i < (lenght) / KB4; i++)
    {
        u64 addr = st_addr + i * KB4;
        void *cr3 = osmap(current->pgd);
        int arr[] = {39, 30, 21, 12};
        u64 *l1 = (u64 *)cr3 + (addr >> 39);
        if (debug2)
            printk("change_permission_pg2 %x\n", l1);

        if (debug2)
            printk("%x %x %x %x\n", l1, *l1, addr, cr3);
        int r = prot % 2, w = (prot / 2) % 2;
        for (int i = 1; i <= 4; i++)
        {
            u64 ad = *l1;
            if (ad % 2)
            {
                if (debug2)
                    printk("1_%d\n", (*l1) & (0x8));

                if (((*l1) & (0x8)) == 0 && w == 1)
                {
                    if (get_pfn_refcount((*l1) >> 12) > 1)
                    {
                     if(debug2)   printk("change_permission_pg:Entered\n");
                        if (i == 4)
                            continue;
                        else
                        {
                            printk("ERROR:change_permission_pg\n");
                            return -1;
                        }
                    }

                    *l1 = ad | 0x8;
                    if (debug2)
                        printk("2_%d\n", (*l1) & (0x8));
                    if (debug2)
                        printk("%x %x %x\n", l1, *l1, addr);
                }

                else if (i == 4 && ((ad & (0x8)) == (0x8)) && w == 0)
                {
                    *l1 = ad ^ 0x8;
                    if (debug2)
                        printk("3_%d\n", (*l1) & (0x8));
                    if (debug2)
                        printk("%x %x %x\n", l1, *l1, addr);
                    return 0;
                }
                l1 = (u64 *)(osmap((*l1) >> 12)) + ((addr >> (arr[i])) & (0x1FF));
                if (debug2)
                    printk("%x %x %x\n", l1, *l1, addr);
            }
            else
            {
                if (debug2)
                    printk("\n", l1, *l1, addr);

                break;
            }
        }
        if (debug2)
            printk("\n");
    }
    return 0;
}

static int cnt=0;
int page_unmap(struct exec_context *current, u64 addr1, int length)
{
   // printk("page_unmap %d %x %d\n",cnt,addr1,length/KB4);
    if(current==0||length<=0)return -1;
    flush_tlb();
    // if (debug2)
    //     printk("page_unmap st_addr: %x, length: %x\n", addr1, length);

    for (int j = 0; j < (length) / KB4; j++)
    {
        
        u64 addr = addr1 + j * KB4;
        // pagefree(current,addr1);
        // continue;
        void *cr3 = osmap(current->pgd);
        int arr[] = {39, 30, 21, 12};
        u64 *l1 = (u64 *)cr3 + (addr >> 39);
        if (debug2)
            printk("change_permission_pg2 %x\n", l1);

        if (debug2)
            printk("%x %x %x %x\n", l1, *l1, addr, cr3);
        for (int i = 1; i <= 4; i++)
        {
            u64 ad = *l1;
            if (ad % 2)
            {
                if (debug2)
                    printk("1_%d\n", (*l1) & (0x8));

                else if (i == 4)
                {
                    if (get_pfn_refcount((*l1) >> 12) > 1)
                    {
                        put_pfn((*l1) >> 12);
                    }
                    else
                        {  
                             put_pfn((*l1) >> 12);
                            os_pfn_free(USER_REG, (*l1) >> 12);
                           // printk("freed%d\n",j+1);
                            }
                    // os_pfn_free(USER_REG, (*l1) >> 12);
                    *l1 = 0x0;
                    if (debug2)
                        printk("%x %x %x\n", l1, *l1, addr);
                   // return 0;
                }
                l1 = (u64 *)(osmap((*l1) >> 12)) + ((addr >> (arr[i])) & (0x1FF));
                if (debug2)
                    printk("%x %x %x\n", l1, *l1, addr);
            }
            else
            {
                if (debug2)
                    printk("\n", l1, *l1, addr);

                break;
            }
        }
        if (debug2)
            printk("\n");
    }
    return 0;
}


long vm_area_mprotect(struct exec_context *current, u64 addr, int length, int prot)
{
    if (debug2)
        printk("\nvm_area_mprotect: %x, length: %x, prot: %x\n", addr, length, prot);
          if(addr<MMAP_AREA_START+KB4)
    {
        return -1;
        addr=MMAP_AREA_START+KB4;
    }
    if (length <= 0 || !current)
    {
        return -EINVAL; // Invalid arguments
    }
     if (!(prot == 1 || prot == 3))
    {
        //printk("here\n");
        return -1;
    }
    if (addr ==0 || (addr < MMAP_AREA_START || addr > MMAP_AREA_END))
    {
        return -1;
    }
    length = (length / KB4) * KB4 + (length % KB4 != 0) * KB4;
    u64 end_addr = addr + length;

    struct vm_area *prev = NULL;
    struct vm_area *vma = current->vm_area;

    while (vma)
    {
        if (vma->vm_end <= addr)
        {
            // The current VMA is completely before the range to unmap
            prev = vma;
            vma = vma->vm_next;
            continue;
        }

        if (vma->vm_start >= end_addr)
        {
            // The current VMA is completely after the range to unmap
            break;
        }

        if (vma->vm_start < addr && vma->vm_end > end_addr)
        {
            // The current VMA spans across the entire range to unmap
            // We need to split this VMA into two VMAs
            if (debug)
            {
                printk("Middle\n");
            }
            if (debug)
                printk("\n\nCase3\n\n"); // checked
            struct vm_area *v1 = os_alloc(sizeof(struct vm_area));
            struct vm_area *v2 = os_alloc(sizeof(struct vm_area));
            stats->num_vm_area += 2;
            v1->vm_start = end_addr;
            v1->vm_end = vma->vm_end;
            v1->access_flags = vma->access_flags;
            v1->vm_next = vma->vm_next;

            v2->vm_start = addr;
            v2->vm_end = end_addr;
            v2->access_flags = prot;
            v2->vm_next = v1;

            vma->vm_end = addr;
            vma->vm_next = v2;
            vma = current->vm_area;
            complete_merge(vma);
            break;
        }

        if (vma->vm_start < addr)
        {
            if (debug)
                printk("\n\nCase2\n\n");
            // The VMA overlaps with the range at the start
            // We need to adjust the end of the VMA
            struct vm_area *v2 = os_alloc(sizeof(struct vm_area));
            stats->num_vm_area++;
            // v1->vm_start = end_addr+1;
            // v1->vm_end = vma->vm_end;
            // v1->access_flags = vma->access_flags;
            // v1->vm_next = vma->vm_next;

            v2->vm_start = addr;
            v2->vm_end = vma->vm_end;
            v2->access_flags = prot;
            v2->vm_next = vma->vm_next;

            vma->vm_end = addr;
            vma->vm_next = v2;
            vma = vma->vm_next;
        }
        else if (vma->vm_end > end_addr)
        {
            if (debug)
                printk("\n\nCase1\n\n"); // checked
            struct vm_area *v1 = os_alloc(sizeof(struct vm_area));
            stats->num_vm_area++;
            v1->vm_start = end_addr;
            v1->vm_end = vma->vm_end;
            v1->access_flags = vma->access_flags;
            v1->vm_next = vma->vm_next;

            vma->access_flags = prot;
            vma->vm_end = addr + length;
            vma->vm_next = v1;
            vma = current->vm_area;
            complete_merge(vma);

            /// correct merge
            // printk("%x %x %x %x\n",vma->vm_start,vma->vm_end,vma->vm_next->vm_start,vma->vm_next->vm_end);
            break;
        }
        else
        {
            if (debug)
                printk("\n\nCase4\n\n"); // checked
            // The VMA is completely within the range to unmap
            // We should remove this VMA
            vma->access_flags = prot;
            vma = vma->vm_next;
        }
    }
    vma = current->vm_area;
    complete_merge(vma);

    change_permission_pg(current, addr, length, prot);
    return 0; // Success
}
//check whehter null
long vm_area_map(struct exec_context *current, u64 addr, int length, int prot, int flags)
{
    if (current == 0)
    {
        return -1;
    }
    if (!(flags == 0 || flags == MAP_FIXED))
    {
        return -1;
    }
    if (!(prot == 1 || prot == 3))
    {
        return -1;
    }
    if (addr != 0 && (addr < MMAP_AREA_START || addr > MMAP_AREA_END))
    {
        return -1;
    }
    if (length >= (KB4 * KB4 / 8))
        return -1;
    if (length <= 0)
        return -1;
    if (current->vm_area == 0)
    {
        current->vm_area = os_alloc(sizeof(struct vm_area));
        current->vm_area->vm_start = MMAP_AREA_START;
        current->vm_area->vm_end = current->vm_area->vm_start + KB4;
        current->vm_area->access_flags = 0;
        current->vm_area->vm_next = 0;
        stats->num_vm_area++;
    }
    struct vm_area *st = current->vm_area;
    int size = (length / KB4) * KB4 + (length % KB4 != 0) * KB4;
    if (addr == 0)
    {
        if (flags == MAP_FIXED)
            return -1;
        while (st->vm_next != 0 && !(st->vm_end + size <= st->vm_next->vm_start))
        {
            st = st->vm_next;
        }
        if (st!=0&&st->access_flags == prot)
        {
            u64 ad = st->vm_end;
            st->vm_end += size;
            merge(st, st->vm_next);
            return ad;
        }

        else
        {
            struct vm_area *nt = os_alloc(sizeof(struct vm_area));
            stats->num_vm_area++;
            nt->vm_start = st->vm_end;
            nt->vm_end = nt->vm_start + size;
            nt->access_flags = prot;
            nt->vm_next = st->vm_next;
            st->vm_next = nt;
            // printk("\n\n\\nMerge\n");
            merge(st->vm_next, nt->vm_next);
            return nt->vm_start;
        }
    }
    else
    {
        while (st!=0&&st->vm_next != 0 && !(st->vm_end <= addr && st->vm_next->vm_start >= addr + size))
        {
            st = st->vm_next;
        }
        if (st!=0&&!(st->vm_end <= addr && st->vm_next->vm_start >= addr + size) && addr < st->vm_end)
        {
            // if(flags==MAP_FIXED)return -1;//checked
            if (flags == 0)
                return vm_area_map(current, 0, length, prot, flags);
            else
                return -1;
        }
        if (addr == st->vm_end && st->access_flags == prot)
        {
            st->vm_end += size;
        }
        else if (st->vm_next->vm_start == addr + size && st->access_flags == prot)
        {
            st->vm_next->vm_start = addr;
        }
        else
        {
            struct vm_area *nt = os_alloc(sizeof(struct vm_area));
            stats->num_vm_area++;
            nt->vm_start = addr;
            nt->vm_end = nt->vm_start + size;
            nt->access_flags = prot;
            nt->vm_next = st->vm_next;
            st->vm_next = nt;
        }
        merge(st, st->vm_next);
        if (st->vm_next != 0)
            merge(st->vm_next, st->vm_next->vm_next);
        return addr;
    }
    return -EINVAL;
}

/**
 * munmap system call implemenations
 */
static int debug7=0;
long vm_area_unmap(struct exec_context *current, u64 addr, int length)
{
   // printk("os:vm_area_unmap %d %x\n",++cnt,addr);
    if (length <= 0 || !current)
    {
        return -EINVAL; // Invalid arguments
    }
    if(addr<MMAP_AREA_START+KB4)
    {
        return -1;
        addr=MMAP_AREA_START+KB4;
    }
    length = (length / KB4) * KB4 + (length % KB4 != 0) * KB4;
    // Calculate the end address based on the given address and length
    u64 end_addr = addr + length;

    struct vm_area *prev = NULL;
    if(current->vm_area==0)return 0;
    struct vm_area *vma = current->vm_area;

    while (vma)
    {
        if (vma->vm_end <= addr)
        {
            if (debug7)
                printk("Unmap_1\n");
            // The current VMA is completely before the range to unmap
            prev = vma;
            vma = vma->vm_next;
            continue;
        }

        if (vma->vm_start >= end_addr)
        {
            // The current VMA is completely after the range to unmap
            break;
        }

        if (vma->vm_start < addr && vma->vm_end > end_addr)
        {
            if (debug7)
                printk("Unmap_2\n"); // checked
            // The current VMA spans across the entire range to unmap
            // We need to split this VMA into two VMAs
            struct vm_area *new_vma = os_alloc(sizeof(struct vm_area));
            stats->num_vm_area++;
            new_vma->vm_start = end_addr;
            new_vma->vm_end = vma->vm_end;
            new_vma->access_flags = vma->access_flags;
            new_vma->vm_next = vma->vm_next;
            vma->vm_end = addr;
            vma->vm_next = new_vma;
            break;
        }

        if (vma->vm_start < addr)
        {
            if (debug7)
                printk("Unmap_3\n"); // checked
            // The VMA overlaps with the range at the start
            // We need to adjust the end of the VMA
            vma->vm_end = addr;
        }
        else if (vma->vm_end > end_addr)
        {
            if (debug7)
                printk("Unmap_4\n"); // cheked
            // The VMA overlaps with the range at the end
            // We need to adjust the start of the VMA
            vma->vm_start = end_addr;
            break;
        }
        else
        {
            // The VMA is completely within the range to unmap
            // We should remove this VMA
            if (debug7)
                printk("Unmap_5\n"); // checked
            if (!prev)
            {
                current->vm_area = vma->vm_next;
            }
            else
            {
                prev->vm_next = vma->vm_next;
            }
            struct vm_area *temp = vma;
            vma = vma->vm_next;
            stats->num_vm_area--;
            os_free(temp, sizeof(struct vm_area));
        }
    }
   page_unmap(current,addr,length);
    return 0; // Success

    return -EINVAL;
}

long vm_area_pagefault(struct exec_context *current, u64 addr, int error_code)
{
   // printk("os:vm_area_pagefault %d\n",error_code);
    if(!(addr>=MMAP_AREA_START&&addr<=MMAP_AREA_END))
    {
        return -1;
    }
      if(addr<MMAP_AREA_START+KB4)
    {
        return -1;
        addr=MMAP_AREA_START+KB4;
    }
    if (debug2)
        printk("\nvm::%x\n", addr);
    struct vm_area *vm = current->vm_area;
    while (vm != 0&&!(vm->vm_start <= addr && vm->vm_end > addr) )
    {
        vm = vm->vm_next;
    }
    if (vm==0||!(vm->vm_start <= addr && vm->vm_end > addr))
    {
        return -1;
    }
    if (debug2)
    {
        printk("vm_area_pagefault %x %x error addr%x\n", vm->vm_start, vm->vm_end, addr);
    }
    if ((error_code == 0x4 && (vm->access_flags % 2 || (vm->access_flags / 2) % 2)) || (error_code == 0x6 && ((vm->access_flags / 2) % 2)))
    {
        if (debug2)
            printk("vm_area_pagefault:%x\n", error_code);

        void *cr3 = osmap(current->pgd);
        if (debug2)
            printk("vm_area_pagefault:%x\n", error_code);

        // u32 pfn=os_pfn_alloc(USER_REG);
        int arr[] = {39, 30, 21, 12};
        u64 *l1 = (u64 *)cr3 + (addr >> 39); // multiply by 8
        if (debug2)
            printk("%x %x %x %x\n", l1, *l1, addr, cr3);
        for (int i = 1; i <= 4; i++)
        {
            u64 ad = *l1;
            if (ad % 2)
            {
                if ((ad & 8 == 0) && (vm->access_flags / 2) % 2)
                {
                    *l1 = ad | 0x8;
                }
                l1 = (u64 *)(osmap((*l1) >> 12)) + ((addr >> (arr[i])) & (0x1FF));
                if (debug2)
                    printk("%x %x %x\n", l1, *l1, addr);

                continue;
            }
            else if (i <= 3)
            {
                // handle_faults(l1, addr, 2, (vm->access_flags / 2) % 2);
                // return 0;
                u32 pfn;
                pfn = os_pfn_alloc(OS_PT_REG);
                *l1 = (pfn << 12) | (1) | (0x10);
                if ((vm->access_flags / 2) % 2)
                {
                    *l1 = (*l1) | 8;
                }
                if (debug2)
                    printk("%x  %x Allocate1\n", l1, *l1);
                l1 = (u64 *)(pfn << 12) + ((addr >> (arr[i])) & (0x1FF));
                if (debug2)
                    printk("%x  %x Allocate1\n", l1, *l1);

                // return 0;
            }
            else if (i == 4)
            {
                // handle_faults(l1, addr, 3, (vm->access_flags / 2) % 2);
                // return 0;
                u32 pfn = os_pfn_alloc(USER_REG);
                *l1 = (pfn << 12) | (1) | (0x10);
                if ((vm->access_flags / 2) % 2)
                {
                    *l1 = (*l1) | 8;
                }
                //*l1=((u64)osmap(pfn))|(addr&0xfff);
                if (debug2)
                    printk("%x %x Allocate2\n\n", l1, *l1);
                return 0;
                // l1=(u64 *)(osmap((*l1) >> 12))+(addr&0xfff);
                // *l1=2;
                // printk("%x %x Allocate2\n",l1, *l1);
            }
            else
            {
                if (debug2)
                    printk("ERror\n");
            }
        }
    }
    else if (error_code == 0x7)
    {
        if (debug2)
            printk("ERRor\n");
        if ((vm->access_flags / 2) % 2 != 1)
            return -1;
        else
            return handle_cow_fault(current, addr, vm->access_flags);
    }
    else
    {
        return -1;
    }

    return -1;
}

/**
 * cfork system call implemenations
 * The parent returns the pid of child process. The return path of
 * the child process is handled separately through the calls at the
 * end of this function (e.g., setup_child_context etc.)
 */
static int debug3 = 0;
int copy_vm(struct exec_context *new_ctx, struct exec_context *ctx)
{
    new_ctx->vm_area = os_alloc(sizeof(struct vm_area));
    new_ctx->vm_area->vm_start = ctx->vm_area->vm_start;
    new_ctx->vm_area->vm_end = ctx->vm_area->vm_end;
    new_ctx->vm_area->access_flags = ctx->vm_area->access_flags;
    new_ctx->vm_area->vm_next = 0;
    //  printk("copy_vm: %x %x\n",new_ctx->vm_area->vm_start,new_ctx->vm_area->vm_end);
    struct vm_area *vm1 = new_ctx->vm_area, *vm2 = ctx->vm_area->vm_next;
    while (vm2 != 0)
    {

        vm1->vm_next = os_alloc(sizeof(struct vm_area));
        vm1 = vm1->vm_next;
        vm1->vm_start = vm2->vm_start;
        vm1->vm_end = vm2->vm_end;
        vm1->access_flags = vm2->access_flags;
        //    printk("copy_vm: %x %x\n",vm1->vm_start,vm1->vm_end);

        vm1->vm_next = 0;
        vm2 = vm2->vm_next;
    }
    return 0;
}

int copy_page_table_fork(struct exec_context *new_ctx, struct exec_context *ctx, u64 addr1, u64 addr2)
{

    if (debug3)
        printk("copy_page_table_fork:%x %x %x\n", addr1, addr2, (addr2 - addr1) / KB4);
    // int cnt = 0;
    int cnt2 = 0;

    for (u64 addr = addr1; addr < addr2; addr += KB4)
    {
        if (debug3)
            printk("loop:%x\n", addr);
        void *cr3 = osmap(new_ctx->pgd);
        void *cr32 = osmap(ctx->pgd);

        int arr[] = {39, 30, 21, 12};
        u64 *l1 = (u64 *)cr3 + (addr >> 39); // new
        u64 *l2 = (u64 *)cr32 + (addr >> 39);
        if (debug3)
            printk("l1:%x %x %x %x\n", l1, *l1, addr, cr3);
        for (int i = 1; i <= 4; i++)
        {
            if ((*l2) % 2 == 0)
            {
                if (debug3)
                    printk("%x here %x\n", i, *l2);
                break;
            }
            if ((i == 4) && (((*l2) & (0x8)) == 0x8))
            {
                *l2 = (*l2) ^ 0x8;
                if (debug3)
                    printk("hi:%x\n", (*l2));
            }
            if (i <= 3)
            {
                if ((*l1) % 2 == 0)
                {
                    u32 pfn;
                    pfn = os_pfn_alloc(OS_PT_REG);
                    *l1 = (pfn << 12) | (1) | (0x10);
                    if (((*l2) & (0x8)) == 0x8)
                    {
                        *l1 = (*l1) | 0x8;
                    }
                    // write bit same as old
                }

                if (debug3)
                    printk("child %x  %x parent %x %x Allocate1\n", l1, *l1, l2, *l2);
                l1 = (u64 *)(osmap((*l1) >> 12)) + ((addr >> (arr[i])) & (0x1FF));
                l2 = (u64 *)(osmap((*l2) >> 12)) + ((addr >> (arr[i])) & (0x1FF));

                if (debug3)
                    printk("child:%x  %x parent:%x %x Allocate2\n", l1, *l1, l2, *l2);
            }
            else if (i == 4)
            {
                cnt2++;
                *l1 = *l2;
                get_pfn((*l2) >> 12);
                if (debug3)
                    printk("last lvl %x %x %x %x Allocate i==4\n\n", l1, *l1, l2, *l2);
            }
            else
            {
                if (debug3)
                    printk("ERror\n");
            }
        }
    }
    if (debug3)
        printk("copy_page_table_fork:%d DOne\n\n", cnt2);
    return 0;
}

int copy_pg_vm(struct exec_context *new_ctx, struct exec_context *ctx)
{
    struct vm_area *vm2 = ctx->vm_area;
    while (vm2 != 0)
    {
        if (debug3)
            printk("copy_vm_pg: %x %x\n", vm2->vm_start, vm2->vm_end);

        copy_page_table_fork(new_ctx, ctx, vm2->vm_start, vm2->vm_end);

        vm2 = vm2->vm_next;
    }
    return 1;
}

static int debug4 = 0;
int cow(struct exec_context *ctx, u64 addr, int access_flags)
{
    int debug5 = 0;
    void *cr3 = osmap(ctx->pgd);

    int arr[] = {39, 30, 21, 12};
    u64 *l1 = (u64 *)cr3 + (addr >> 39);
    if (debug5)
        printk("cowmyfunc:l1:%x %x addr_accessed:%x %x\n", l1, *l1, addr, cr3);
    for (int i = 1; i <= 4; i++)
    {
        if ((*l1) % 2 == 0)
        {
            printk("cow:Error\n");
            if (debug5)
                printk("%x here %x\n", i, *l1);
            return -1;
        }
        if (i <= 3)
        {
            if (debug5)
                printk("child %x  %x parent Allocate1\n", l1, *l1);
            l1 = (u64 *)(osmap((*l1) >> 12)) + ((addr >> (arr[i])) & (0x1FF));
        }
        else if (i == 4)
        {
            if (debug5)
                printk("pid %d\n", ctx->pid);
            if ((((*l1) & (0x8)) == 0x0) && (access_flags / 2) % 2)
            {
                if (debug5)
                    printk("Hurrah\n");
                if (debug5)
                    printk("last lvl %x %x  Allocate i==4\n\n", l1, *l1);
                if (get_pfn_refcount((*l1) >> 12) > 1)
                {
                    u64 l2 = *l1;
                    put_pfn((*l1) >> 12);
                    u64 pfn = os_pfn_alloc(USER_REG);
                    *l1 = (pfn << 12) | 0x10 | 0x1 | 0x8;
                    memcpy(pfn << 12, (l2 >> 12) << 12, KB4);
                    flush_tlb();
                }
                else
                {
                    *(l1) = (*l1) | 0x8;
                }
            }
            if (debug5)
                printk("last lvl %x %x  Allocate i==4\n\n", l1, *l1);
        }
        else
        {
            if (debug5)
                printk("ERror\n");
        }
    }

    if (debug5)
        printk("cow:DOne %x\n\n", addr);
    return 0;
}

long do_cfork()
{
    if (debug4)
    {
        printk("::Fork\n");
    }
    u32 pid;
    struct exec_context *new_ctx = get_new_ctx();
    struct exec_context *ctx = get_current_ctx();
    /* Do not modify above lines
     *
     * */
    // /--------------------- Your code [start]---------------/
    if (debug4)
        printk("fork1: %x %x\n", new_ctx->pid, ctx->pid);

    flush_tlb();
    pid = new_ctx->pid;
    memcpy(new_ctx, ctx, sizeof(struct exec_context));
    new_ctx->pid = pid;
    new_ctx->ppid = ctx->pid;
    copy_vm(new_ctx, ctx);
    new_ctx->pgd = os_pfn_alloc(OS_PT_REG);
    if (debug4)
        printk("fork2: %x %x %x %x\n", new_ctx->pid, ctx->pid, ctx->pgd, new_ctx->pgd);

    copy_page_table_fork(new_ctx, ctx, ctx->mms[MM_SEG_CODE].start, ctx->mms[MM_SEG_CODE].next_free);
    copy_page_table_fork(new_ctx, ctx, ctx->mms[MM_SEG_RODATA].start, ctx->mms[MM_SEG_RODATA].next_free);
    copy_page_table_fork(new_ctx, ctx, ctx->mms[MM_SEG_DATA].start, ctx->mms[MM_SEG_DATA].next_free);
    copy_page_table_fork(new_ctx, ctx, ctx->mms[MM_SEG_STACK].start, ctx->mms[MM_SEG_STACK].end);
    copy_pg_vm(new_ctx, ctx);
    if (debug4)
        printk("fork3:Done\n");
    // /--------------------- Your code [end] ----------------/

    /*
     * The remaining part must not be changed
     */
    flush_tlb();
    copy_os_pts(ctx->pgd, new_ctx->pgd);
    do_file_fork(new_ctx);
    setup_child_context(new_ctx);
    return pid;
}

/* Cow fault handling, for the entire user address space
 * For address belonging to memory segments (i.e., stack, data)
 * it is called when there is a CoW violation in these areas.
 *
 * For vm areas, your fault handler 'vm_area_pagefault'
 * should invoke this function
 * */

long handle_cow_fault(struct exec_context *current, u64 vaddr, int access_flags)
{
    flush_tlb();
    if ((access_flags / 2) % 2 == 1)
    {
        cow(current, vaddr, access_flags);
        return 1;
    }
    printk("handle_cow_fault\n");

    return -1;
}
