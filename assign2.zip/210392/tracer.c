#include <context.h>
#include <memory.h>
#include <lib.h>
#include <entry.h>
#include <file.h>
#include <tracer.h>

int arguments(u64 n)
{
	// implement switch case if syscall_no is not valid return -1;
	if (n == 1)
		return 1;
	else if (n == 2)
		return 0;
	else if (n == 4)
		return 2;
	else if (n == 5)
		return 3;
	else if (n == 6)
		return 1;
	else if (n == 7)
		return 1;
	else if (n == 8)
		return 2;
	else if (n == 9)
		return 2;
	else if (n == 10)
		return 0;
	else if (n == 11)
		return 0;
	else if (n == 12)
		return 1;
	else if (n == 13)
		return 0;
	else if (n == 14)
		return 1;
	else if (n == 15)
		return 0;
	else if (n == 16)
		return 4;
	else if (n == 17)
		return 2;
	else if (n == 18)
		return 3;
	else if (n == 19)
		return 1;
	else if (n == 20)
		return 0;
	else if (n == 21)
		return 0;
	else if (n == 22)
		return 0;
	else if (n == 23)
		return 2;
	else if (n == 24)
		return 3;
	else if (n == 25)
		return 3;
	else if (n == 27)
		return 1;
	else if (n == 28)
		return 2;
	else if (n == 29)
		return 1;
	else if (n == 30)
		return 3;
	else if (n == 35)
		return 4;
	else if (n == 36)
		return 1;
	else if (n == 37)
		return 2;
	else if (n == 38)
		return 0;
	else if (n == 39)
		return 3;
	else if (n == 40)
		return 2;
	else if (n == 41)
		return 3;
	else if (n == 61)
		return 0;
	else
		return -1;
}

///////////////////////////////////////////////////////////////////////////
//// 		Start of Trace buffer functionality 		      /////
///////////////////////////////////////////////////////////////////////////

// Depends on access flags
int debug = 0;
int debug2 = 0;
int is_valid_mem_range(unsigned long buff, u32 count, int access_bit)
{
	if (buff == 0)
		return 0;
	struct exec_context *ctx = get_current_ctx();
	int read = access_bit % 2;
	int write = (access_bit / 2) % 2;
	int execute = access_bit / 4;
	int f = 0;
	if (debug)
	{
		printk("EWR %d%d%d\n", execute, write, read);
		printk("buff:%x %x\n", buff, buff + (unsigned long)count);
		printk("stack:%x %x\n", ctx->mms[MM_SEG_STACK].start, ctx->mms[MM_SEG_STACK].end);
		printk("%x %x\n", ctx->vm_area->vm_start, ctx->vm_area->vm_end);
	}

	if ((buff >= ctx->mms[MM_SEG_CODE].start && (buff + count) <= ctx->mms[MM_SEG_CODE].next_free) || (buff >= ctx->mms[MM_SEG_CODE].next_free && (buff + count) <= ctx->mms[MM_SEG_CODE].start))
	{
		if (debug)
			printk("CODE\n");
		if (write)
			return 0;
		if (read)
			return 1;
	}
	else if ((buff >= ctx->mms[MM_SEG_RODATA].start && (buff + count) <= ctx->mms[MM_SEG_RODATA].next_free) || (buff >= ctx->mms[MM_SEG_RODATA].next_free && (buff + count) <= ctx->mms[MM_SEG_RODATA].start))
	{
		if (debug)
			printk("READ Data SEG\n");
		if (write)
			return 0;
		if (read)
			return 1;
	}
	else if ((buff >= ctx->mms[MM_SEG_DATA].start && (buff + count) <= ctx->mms[MM_SEG_DATA].next_free) || (buff >= ctx->mms[MM_SEG_DATA].next_free && (buff + count) <= ctx->mms[MM_SEG_DATA].start))
	{
		if (debug)
			printk("DATA SEG\n");
		return 1;
	}
	else if ((buff >= ctx->mms[MM_SEG_STACK].start && (buff + count) <= ctx->mms[MM_SEG_STACK].end) || buff >= ctx->mms[MM_SEG_STACK].end && (buff + count) <= ctx->mms[MM_SEG_STACK].start)
	{
		if (debug)
			printk("STACK\n");
		return 1;
	}
	else if (ctx->vm_area != 0)
	{
		// treat it like linked list
		struct vm_area *vm = ctx->vm_area;
		struct vm_area *st = vm;

		if (vm != 0)
		{
			if (buff >= vm->vm_start && (buff + count) <= vm->vm_end)
			{
				if (debug)
				{
					printk("VM %x %x %x\n",vm->vm_start,vm->vm_end,buff);
				}
				if ((vm->access_flags % 2) == read)
					return 1;
				else if (((vm->access_flags / 2) % 2) == write)
					return 1;
				else
					return 0;
			}
			vm = vm->vm_next;
		}

		while (vm != 0 && vm != st)
		{
			if (buff >= vm->vm_start && (buff + count) <= vm->vm_end)
			{
				if (debug)
				{
					printk("VM %x %x %x\n",vm->vm_start,vm->vm_end,buff);
				}
				if ((vm->access_flags % 2) == read)
					return 1;
				else if (((vm->access_flags / 2) % 2) == write)
					return 1;
				else
					return 0;
			}
			vm = vm->vm_next;
		}
	}
	else
	{
		if (debug)
			printk("else_is_valid\n");

		return 0;
	}

	return 0;
}
long trace_buffer_close(struct file *filep)
{
	if (filep == 0)
		return -EINVAL;
	if (filep->type != TRACE_BUFFER)
		return -EINVAL;
	struct exec_context *ctx = get_current_ctx();
	int f = -1;
	for (int i = 0; i < MAX_OPEN_FILES; i++)
	{
		if (ctx->files[i] == filep)
		{
			f = i;
			ctx->files[i] = 0;
			break;
		}
	}
	// printk("c5 %x %x %d\n",ctx->files[3],filep, f);
	// if (f == -1)
	// 	return -EINVAL;
	// if (debug)
	//	printk("c3\n");

	if (filep->fops != 0)
	{ os_free(filep->fops, sizeof(struct fileops));
		//os_page_free(USER_REG, filep->fops);
	}
	else
		return -EINVAL;
	// if (debug)
	//	printk("c2\n");
	if (filep->trace_buffer != 0 && filep->trace_buffer->buffer != 0)
		os_page_free(USER_REG, filep->trace_buffer->buffer);
	else
		return -EINVAL;

	// if (debug)
	// printk("c1\n");
	if (filep->trace_buffer != 0)
	{
		//os_page_free(USER_REG, filep->trace_buffer);
		 os_free(filep->trace_buffer, sizeof(struct trace_buffer_info));
	}
	else
		-EINVAL;
	//os_page_free(USER_REG, filep);
	 os_free(filep, sizeof(struct file));
	return 0;
}

int trace_buffer_read(struct file *filep, char *buff, u32 count)
{
	if (debug)
		printk("READ_%d\n", count);
	if (count < 0 || filep == 0)
		return -EINVAL;
	int retval = is_valid_mem_range((unsigned long)buff, count, 2);
	if (debug)
		printk("READ %d buff:%x\n", retval, buff);
	if (retval == 0)
		return -EBADMEM;
	int read = 0;
	while (read < count && filep->trace_buffer->size > 0)
	{
		buff[read++] = filep->trace_buffer->buffer[filep->trace_buffer->r];
		// printk("%c ",filep->trace_buffer->buffer[filep->trace_buffer->r]);
		filep->trace_buffer->size--;
		filep->trace_buffer->buffer[filep->trace_buffer->r++] = 0;
		filep->trace_buffer->r %= TRACE_BUFFER_MAX_SIZE;
	}
	// if(error)return ENOMEM;
	// printk("\n");
	return read;
}

int trace_buffer_write(struct file *filep, char *buff, u32 count)
{
	if (debug)
		printk("write to buf\n");
	if (count < 0 || filep == 0)
		return -EINVAL;
	int retval = is_valid_mem_range((unsigned long)buff, count, 1);
	if (debug)
		printk("WRITE %d\n", retval);
	if (retval == 0)
		return -EBADMEM;
	int written = 0;

	while (written < count && filep->trace_buffer->size < TRACE_BUFFER_MAX_SIZE)
	{
		filep->trace_buffer->buffer[filep->trace_buffer->w] = buff[written++];
		filep->trace_buffer->size++;
		// printk("%c ",filep->trace_buffer->buffer[filep->trace_buffer->w]);
		filep->trace_buffer->w = (filep->trace_buffer->w + 1) % TRACE_BUFFER_MAX_SIZE;
	}
	// if(error)return ENOMEM;
	//  printk("\n");
	return written;
}

int sys_create_trace_buffer(struct exec_context *current, int mode)
{
	if (debug)
		printk("create traceer\n");

	if (current == NULL || (!(mode == O_RDWR || mode == O_READ || mode == O_WRITE)))
		return -EINVAL;
	// struct file* files[MAX_OPEN_FILES]; /*To keep record of openfiles */
	int f = -1;
	for (int i = 0; i < MAX_OPEN_FILES; i++)
	{
		if (current->files[i] == 0)
		{
			f = i;
			break;
		}
	}

	if (f == -1)
		return -EINVAL;

	struct file *filep = os_alloc(sizeof(struct file));
	//struct file *filep = (struct file *)os_page_alloc(USER_REG);
	if (filep == 0)
		return -ENOMEM;

	current->files[f] = filep;

	if (debug)
		printk("Create fd %d %x %x\n", f, current->files[f], filep);

	filep->type = TRACE_BUFFER;
	filep->mode = mode;
	filep->offp = 0;	  // check
	filep->ref_count = 0; // check
	filep->inode = 0;
	 filep->trace_buffer = os_alloc(sizeof(struct trace_buffer_info));

	//filep->trace_buffer = os_page_alloc(USER_REG);
	if (filep->trace_buffer == 0)
		return -ENOMEM;

	filep->trace_buffer->r = 0;
	filep->trace_buffer->w = 0;
	filep->trace_buffer->size = 0;

	filep->trace_buffer->buffer = (char *)os_page_alloc(USER_REG);
	if (filep->trace_buffer->buffer == 0)
		return -ENOMEM;
	// filep->trace_buffer->buffer = (void *)os_page_alloc(USER_REG);
	for (int i = 0; i < TRACE_BUFFER_MAX_SIZE; i++)
	{
		filep->trace_buffer->buffer[i] = 0;
	}
	// printk("%d %d %d\n",sizeof(struct file),sizeof(struct trace_buffer_info),sizeof(struct fileops));
	//filep->fops = os_page_alloc(USER_REG);
	 filep->fops = os_alloc(sizeof(struct fileops));
	if (filep->fops == 0)
		return -ENOMEM;
	filep->fops->read = trace_buffer_read;
	filep->fops->write = trace_buffer_write;
	filep->fops->close = trace_buffer_close;
	filep->fops->lseek = 0;

	return f;
	// if(error)return -ENOMEM;
}

///////////////////////////////////////////////////////////////////////////
//// 		Start of strace functionality 		      	      /////
///////////////////////////////////////////////////////////////////////////
int debug4 = 0;
int perform_tracing(u64 syscall_num, u64 param1, u64 param2, u64 param3, u64 param4)
{ // if flag=0 then return 0

	if (syscall_num == 38 || syscall_num == 37 || syscall_num == 1)
		return 0;
	struct exec_context *ctx = get_current_ctx();
	if (ctx == 0 || ctx->st_md_base == 0)
		return 0;
	if (ctx->st_md_base != 0 && ctx->st_md_base->is_traced == 0)
		return 0;

	if (debug4)
		printk("\nPerform %d ", syscall_num);

	if (ctx->st_md_base->tracing_mode == FILTERED_TRACING)
	{
		int flag = 0;
		struct strace_info *info = ctx->st_md_base->next;
		while (info != 0)
		{
			/* code */
			if (info->syscall_num == syscall_num)
			{

				flag = 1;
				break;
			}
			if (debug4)
				printk(" %d ", info->syscall_num);
			info = info->next;
		}
		if (debug4)
			printk(" \n", syscall_num);

		if (flag == 0)
			return 0;
	}
	int fd = ctx->st_md_base->strace_fd;
	// struct file *filep = ctx->files[fd];
	int args = arguments(syscall_num);
	if (args == -1)
		return -EINVAL;
	if (debug2)
		printk("Perform_trace %d %d\n", syscall_num, args);

	if (debug4)
		printk("Performing %d\n", syscall_num);

	// char *buf = (char *)os_alloc(args * 8 + 8);
	u64 buf[args + 1];
	// printk("VM %x %x\n", ctx->vm_area->vm_start, ctx->vm_area->vm_end);
	u64 arr[] = {syscall_num, param1, param2, param3, param4};
	for (int i = 0; i < args + 1; i++)
	{
		// 	for (int j = 7; j >= 0; j--)
		// 	{
		// 		buf[i * 8 + j] = arr[i] % 256;
		// 		arr[i] /= 256;
		// }
		buf[i] = arr[i];
	}
	// printk("Buff add%x\n",buf);
	// int v = trace_buffer_write(ctx->files[fd], buf, args * 8 + 8);
	// printk("Written %d\n\n\n", v);

	int count = 8 * args + 8;
	int written = 0;
	if (fd < 0 || fd >= MAX_OPEN_FILES || ctx->files[fd] == 0 || ctx->files[fd]->trace_buffer == 0)
		return 0;
	while (written < count && ctx->files[fd]->trace_buffer->size < TRACE_BUFFER_MAX_SIZE)
	{
		ctx->files[fd]->trace_buffer->buffer[ctx->files[fd]->trace_buffer->w] = ((char *)buf)[written++];
		ctx->files[fd]->trace_buffer->size++;
		// printk("%c ",filep->trace_buffer->buffer[filep->trace_buffer->w]);
		ctx->files[fd]->trace_buffer->w = (ctx->files[fd]->trace_buffer->w + 1) % TRACE_BUFFER_MAX_SIZE;
	}
	if (debug4)
		printk("Written %d %d %d %d %d\n", written, count, ctx->files[fd]->trace_buffer->r, ctx->files[fd]->trace_buffer->w, ((u64 *)(ctx->files[fd]->trace_buffer->buffer))[ctx->files[fd]->trace_buffer->r]);
	if (written != count)
		return -EINVAL;
	// if(error)return ENOMEM;
	// printk(" %d\n", count);
	if (debug2)
		printk("Written %d\n\n", written);
	return 0;
}

int sys_strace(struct exec_context *current, int syscall_num, int action)
{

	if (current == 0 || (action != ADD_STRACE && action != REMOVE_STRACE) || syscall_num < 0)
		return -EINVAL;
	if (arguments(syscall_num) < 0)
		return -EINVAL;
	if (debug2)
		printk("sys_strace  \n\n\n");
	if (action == ADD_STRACE)
	{
		if (current->st_md_base == 0)
		{
			 current->st_md_base = os_alloc(sizeof(struct strace_head));
			//current->st_md_base = os_page_alloc(USER_REG);
			current->st_md_base->count = 0;
			current->st_md_base->next = 0;
			current->st_md_base->last = 0;
			current->st_md_base->is_traced = 0;
		}
		if (current->st_md_base->next == 0)
		{
			current->st_md_base->next = (struct strace_info *)os_alloc(sizeof(struct strace_info));
			//current->st_md_base->next = os_page_alloc(USER_REG);
			current->st_md_base->next->next = 0;
			current->st_md_base->next->syscall_num = syscall_num;
			current->st_md_base->last = current->st_md_base->next;
			current->st_md_base->count++;
		}
		else
		{
			struct strace_info *info = current->st_md_base->next;
			int f = 0;
			while (info->next != 0)
			{
				if (info->syscall_num == syscall_num)
				{
					// return -9;
					return -EINVAL;
				}
				info = info->next;
			}
			if (info->syscall_num == syscall_num)
			{
				// return -10;
				return -EINVAL;
			}
			if (current->st_md_base->count >= STRACE_MAX)
			{
				// return -11;
				return -EINVAL;
			}
			//info->next = os_page_alloc(USER_REG);
			info->next = (struct strace_info *)os_alloc(sizeof(struct strace_info));
			info->next->next = 0;
			info->next->syscall_num = syscall_num;
			current->st_md_base->last = info->next;
			current->st_md_base->count++;
			if (debug2)
				printk("STRACE%d %d %x\n", syscall_num, current->st_md_base->count, MAX_STRACE);
		}
		return 0;
	}
	else
	{
		if (current->st_md_base->next == 0)
			return -EINVAL;
		if (current->st_md_base->next->syscall_num == syscall_num)
		{
			if (current->st_md_base->last == current->st_md_base->next)
			{
				current->st_md_base->last = 0;
			}
			struct strace_info *info2 = current->st_md_base->next;

			current->st_md_base->next = current->st_md_base->next->next;
			current->st_md_base->count--;
			//os_page_free(USER_REG, info2);
			 os_free(info2, sizeof(struct strace_info));

			return 0;
		}
		struct strace_info *info = current->st_md_base->next;
		while (info->next != 0)
		{
			if (info->next->syscall_num == syscall_num)
			{
				struct strace_info *info2 = info->next;
				info->next = info->next->next;
				current->st_md_base->count--;
				if (current->st_md_base->last == info2)
				{
					current->st_md_base->last = 0;
				}
				//os_page_free(USER_REG, info2);
				 os_free(info2, sizeof(struct strace_info));
				return 0;
			}
			info = info->next;
		}
		return -EINVAL;
	}
	return 0;
}

int sys_read_strace(struct file *filep, char *buff, u64 count)
{
	if (filep == 0 || buff == 0 || count < 0)
		return -EINVAL;
	if (filep->type != TRACE_BUFFER || filep->trace_buffer == 0 || filep->trace_buffer->buffer == 0)
		return -EINVAL;
	int i = 0;
	for (int j = 0; j < count; j++)
	{
		int v = trace_buffer_read(filep, buff + i, 8);
		if (v == 0)
		{
			if (debug2)
				printk("READ_STRACE %d\n", i);
			return i;
		}
		if (v < 8)
		{
			if (debug2)
				printk("ERROR READ %d\n", v);
			return -EINVAL;
		}
		// u64 *v2=(u64 *)(buff+i);
		u64 val = ((u64 *)(buff + i))[0];
		// int val = 0;
		// for (int t = 7; t >=0; t--)
		// {
		// 	val = val * 256 + (buff + i + t)[0];
		// }

		if (debug2)
			printk("**Read_strace %x %d %d %d val***\n", val);
		i += 8;
		int args = arguments(val);
		if (args == -1)
			return -EINVAL;
		v = trace_buffer_read(filep, buff + i, 8 * args);
		if (v != 8 * arguments(val))
		{
			if (debug2)
				printk("ERROR READ%d\n", v);
			return -EINVAL;
		}
		i += 8 * args;
		if (debug2)
			printk("READ %d %d\n", i, 8 * args + 8);
	}
	if (debug2)
		printk("READ_STRACE %d\n", i);
	return i;
}

int sys_start_strace(struct exec_context *current, int fd, int tracing_mode)
{
	if (current == 0 || (tracing_mode != FULL_TRACING && tracing_mode != FILTERED_TRACING))
		return -EINVAL;
	if (fd < 0 || fd > MAX_OPEN_FILES)
		return -EINVAL;
	if (current->st_md_base == 0)
	{
		//current->st_md_base = os_page_alloc(USER_REG);
		current->st_md_base = os_alloc(sizeof(struct strace_head));
		if (current->st_md_base == 0)
			return -EINVAL;
		current->st_md_base->count = 0;
		current->st_md_base->next = 0;
		current->st_md_base->last = 0;
	}
	current->st_md_base->tracing_mode = tracing_mode;
	current->st_md_base->strace_fd = fd;
	current->st_md_base->is_traced = 1;
	if (debug2)
	{
		printk("Start strace %x %d \n", current->files[fd], current->st_md_base->tracing_mode);
		printk("%x %d\n", current->files[fd]->trace_buffer->buffer, current->files[fd]->trace_buffer->size);
	}
	return 0;
}

int sys_end_strace(struct exec_context *current)
{
	if (current == 0 || current->st_md_base == 0 || current->st_md_base->is_traced != 1)
		return -EINVAL;
	current->st_md_base->tracing_mode = 0;
	current->st_md_base->count = 0;
	current->st_md_base->is_traced = 0;
	struct strace_info *info = current->st_md_base->next;
	current->st_md_base->next = 0;
	current->st_md_base->last = 0;
	while (info != 0)
	{
		struct strace_info *next = info->next;
		//os_page_free(USER_REG, info);
		os_free(info,sizeof(struct strace_info));
		// int v = os_free(info, sizeof(struct strace_info));
		//  if (v == 0)
		//  {
		//  	return -EINVAL;
		//  }
		info = next;
	}
			os_free(current->st_md_base,sizeof(struct strace_head));

	// os_page_free(USER_REG,current->st_md_base);
	current->st_md_base=0;
	if (debug2)
		printk("END STRACE\n");
	return 0;
}

int debug3 = 0;
long do_ftrace(struct exec_context *current, unsigned long faddr, long action, long nargs, int fd_trace_buffer)
{
	if (current == 0)
	{
		return -EINVAL;
	}
	if (action == ADD_FTRACE)
	{
		if (current->ft_md_base == 0)
		{
			//current->ft_md_base = os_page_alloc(USER_REG);
			 current->ft_md_base = os_alloc(sizeof(struct ftrace_head));
			current->ft_md_base->count = 0;
			current->ft_md_base->next = 0;
			current->ft_md_base->last = 0;
		}
		if (current->ft_md_base->next == 0)
		{
			//current->ft_md_base->next = os_page_alloc(USER_REG);
			current->ft_md_base->next = (struct ftrace_info *)os_alloc(sizeof(struct ftrace_info));
			current->ft_md_base->next->next = 0;
			current->ft_md_base->next->fd = fd_trace_buffer;
			current->ft_md_base->next->num_args = nargs;
			current->ft_md_base->next->faddr = faddr;
			current->ft_md_base->last = current->ft_md_base->next;
			current->ft_md_base->count++;
		}
		else
		{
			struct ftrace_info *info = current->ft_md_base->next;
			while (info->next != 0)
			{
				if (info->faddr == faddr)
				{
					return -EINVAL;
				}
				info = info->next;
			}
			if (info->faddr == faddr)
			{
				return -EINVAL;
			}
			// printk("%d %d\n",syscall_num,current->st_md_base->count);
			if (current->st_md_base->count >= FTRACE_MAX)
				return -EINVAL;
			//info->next = os_page_alloc(USER_REG);
			 info->next = (struct ftrace_info *)os_alloc(sizeof(struct ftrace_info));
			info->next->next = 0;
			info->next->faddr = faddr;
			info->next->fd = fd_trace_buffer;
			info->next->num_args = nargs;
			current->ft_md_base->last = info->next;
			current->ft_md_base->count++;
		}
		return 0;
	}
	else if (action == REMOVE_FTRACE)
	{
		if (current->ft_md_base->next == 0)
			return -EINVAL;
		struct ftrace_info *info2 = 0;

		if (current->ft_md_base->next->faddr == faddr)
		{
			if (current->ft_md_base->last == current->ft_md_base->next)
			{
				current->ft_md_base->last = 0;
			}
			info2 = current->ft_md_base->next;

			current->ft_md_base->next = current->ft_md_base->next->next;
			current->ft_md_base->count--;
		}
		struct ftrace_info *info = current->ft_md_base->next;
		while (info->next != 0)
		{
			if (info->next->faddr == faddr)
			{
				info2 = info->next;
				info->next = info->next->next;
				current->ft_md_base->count--;
				if (current->ft_md_base->last == info2)
				{
					current->ft_md_base->last = 0;
				}
				break;
			}
			info = info->next;
		}
		if (info2 == 0)
			return -EINVAL;
		u8 *ptr = (u8 *)faddr;
		int cnt = 0;
		for (int i = 0; i < 4; i++)
		{
			if (*(ptr + i) == INV_OPCODE)
			{
				cnt++;
				// printk("ERROR %d\n",i);
				// return -EINVAL;
				*(ptr + i) = info2->code_backup[i];
			}
		}
		//printk("Hi\n");
		os_free(info2,sizeof(struct ftrace_info));
		//os_page_free(USER_REG, info2);
				//printk("Hi\n");

		if (cnt == 0 || cnt == 4)
			return 0;
		else
			return -EINVAL;
	}
	else if (action == ENABLE_FTRACE)
	{
		if (debug3)
			printk("ENABLE ftrace\n");
		u8 *ptr = (u8 *)faddr;
		struct ftrace_info *info = current->ft_md_base->next;
		while (info != 0)
		{
			if (info->faddr == faddr)
			{
				for (int i = 0; i < 4; i++)
				{
					if (*(ptr + i) != INV_OPCODE)
					{
						info->code_backup[i] = *(ptr + i);
						*(ptr + i) = INV_OPCODE;
					}
				}
				return 0;
			}
			info = info->next;
		}
		return -EINVAL;
		// printk("%x\n", faddr);
		// //*(ptr + 8) = INV_OPCODE;
		// printk("SHould generate %x %x %x\n", *(u64 *)faddr, *(u8 *)faddr, faddr);
	}
	else if (action == DISABLE_FTRACE)
	{
		if (debug3)
			printk("ENABLE ftrace\n");
		u8 *ptr = (u8 *)faddr;
		struct ftrace_info *info = current->ft_md_base->next;
		while (info != 0)
		{
			int cnt = 0;
			if (info->faddr == faddr)
			{
				for (int i = 0; i < 4; i++)
				{
					if (*(ptr + i) == INV_OPCODE)
					{
						cnt++;
						*(ptr + i) = info->code_backup[i];
					}
				}
				if (cnt != 4 && cnt != 0)
					return -EINVAL;
				return 0;
			}
			info = info->next;
		}
		return -EINVAL;
	}
	else if (action == ENABLE_BACKTRACE)
	{

		if (debug3)
			printk("ENABLE BACKTRACE\n");
		u8 *ptr = (u8 *)faddr;
		int cnt = -1;
		struct ftrace_info *info = current->ft_md_base->next;
		while (info != 0)
		{
			if (info->faddr == faddr)
			{
				cnt = 0;
				for (int i = 0; i < 4; i++)
				{
					if (*(ptr + i) != INV_OPCODE)
					{
						info->code_backup[i] = *(ptr + i);
						*(ptr + i) = INV_OPCODE;
						cnt++;
					}
				}

				break;
			}
			info = info->next;
		}
		if (cnt == -1)
			return -EINVAL;
		if (cnt != 0 && cnt != 4)
			return -EINVAL;
		else
		{
			info->capture_backtrace = 1;
			return 0;
		}
	}
	else if (action == DISABLE_BACKTRACE)
	{
		u8 *ptr = (u8 *)faddr;
		int cnt = -1;
		struct ftrace_info *info = current->ft_md_base->next;
		while (info != 0)
		{
			if (info->faddr == faddr)
			{
				cnt = 0;
				for (int i = 0; i < 4; i++)
				{
					if (*(ptr + i) == INV_OPCODE)
					{
						*(ptr + i) = info->code_backup[i];
						cnt++;
					}
				}

				break;
			}
			info = info->next;
		}
		if (cnt == -1)
			return -EINVAL;
		if (cnt != 0 && cnt != 4)
			return -EINVAL;
		else
		{
			info->capture_backtrace = 0;
			return 0;
		}
	}
	else
	{
		return -EINVAL;
	}
	return 0;
}

// Fault handler
long handle_ftrace_fault(struct user_regs *regs)
{
	if (debug3)
		printk("Handler %x %x %x %x\n", *(u64 *)(regs->entry_rsp), *(u64 *)(regs->entry_rsp + 8), *(u64 *)(regs->rbp), *(u64 *)(regs->rbp + 8));

	struct exec_context *ctx = get_current_ctx();
	struct ftrace_info *info = ctx->ft_md_base->next;
	int f = 0;
	while (info != 0)
	{
		if (info->faddr == regs->entry_rip)
		{
			f = 1;
			break;
		}
		info = info->next;
	}
	if (f == 0)
	{
		return -EINVAL;
	}

	regs->entry_rsp -= 8;
	*((u64 *)regs->entry_rsp) = regs->rbp;
	regs->rbp = regs->entry_rsp;
	regs->entry_rip = regs->entry_rip + 4;

	u64 buf[4096];
	int count = 8 * info->num_args + 8;

	// ctx->files[info->fd]->trace_buffer->buffer
	u64 arr[] = {info->faddr, regs->rdi, regs->rsi, regs->rdx, regs->rcx, regs->r8, regs->r9};
	int i;
	for (i = 1; i <= 1 + info->num_args; i++)
	{
		buf[i] = arr[i - 1];
	}
	if (debug3)
		printk("%d ", count);
	if (info->capture_backtrace == 1)
	{
		buf[i++] = info->faddr;
		count += 8;
		u64 ptr = regs->rbp;
		// printk("hi1\n");
		while ((*(u64 *)(ptr + 8)) != END_ADDR)
		{
			// printk("I am here\n");
			buf[i++] = *((u64 *)(ptr + 8));

			count += 8;
			// printk("hi2 %x %x %x", ptr, *((u64 *)(ptr)), END_ADDR);

			ptr = *((u64 *)(ptr));
			// printk(" hi2 %x %d\n", ptr,i);
		}
	}

	// printk("hi3\n");
	buf[0] = count;
	int fd = info->fd;
	int written = 0;
	if (fd < 0 || fd >= MAX_OPEN_FILES || ctx->files[fd] == 0 || ctx->files[fd]->trace_buffer == 0)
		return 0;
	while (written < count + 8 && ctx->files[fd]->trace_buffer->size < TRACE_BUFFER_MAX_SIZE)
	{
		ctx->files[fd]->trace_buffer->buffer[ctx->files[fd]->trace_buffer->w] = ((char *)buf)[written++];
		ctx->files[fd]->trace_buffer->size++;
		// printk("%c ",filep->trace_buffer->buffer[filep->trace_buffer->w]);
		ctx->files[fd]->trace_buffer->w = (ctx->files[fd]->trace_buffer->w + 1) % TRACE_BUFFER_MAX_SIZE;
	}
	if (debug3)
		printk("Handler exit%d\n", count + 8);
	if (written != count + 8)
		return -EINVAL;

	return 0;
}

int sys_read_ftrace(struct file *filep, char *buff, u64 count)
{

	if (filep == 0 || buff == 0 || count < 0)
		return -EINVAL;
	if (filep->type != TRACE_BUFFER || filep->trace_buffer == 0 || filep->trace_buffer->buffer == 0)
		return -EINVAL;
	int i = 0;
	for (int j = 0; j < count; j++)
	{
		int v = trace_buffer_read(filep, buff + i, 8);
		if (v == 0)
		{
			if (debug3)
				printk("READ_STRACE %d\n", i);
			return i;
		}
		if (v < 8)
		{
			if (debug3)
				printk("ERROR READ %d\n", v);
			return -EINVAL;
		}
		u64 val = ((u64 *)(buff + i))[0];

		if (debug3)
			printk("**Read_strace %x %d %d %d val***\n", val);
		// i += 8;
		v = trace_buffer_read(filep, buff + i, val);
		if (v != val)
		{
			if (debug3)
				printk("ERROR READ%d\n", v);
			return -EINVAL;
		}
		i += val;
	}
	if (debug3)
		printk("READ_STRACE %d\n", i);
	return i;
	return 0;
}








